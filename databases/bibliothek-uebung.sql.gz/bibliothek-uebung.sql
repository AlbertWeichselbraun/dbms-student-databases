--- Bibliotheksdatenbank

create table Benutzer(
ID integer  Primary Key,
Name varchar (30),
Alter integer,
Adresse varchar (60)
);

CREATE TABLE Exemplar(
  Signatur varchar(20) Primary Key, 
  ISBN integer
);

create table Buch(
  ISBN integer Primary key,
  Titel varchar (30),
  Autor varchar (30),
  Verlag varchar (30)
);

CREATE TABLE Mahnung(
  Entlehnt DATE,
  Faellig DATE,
  Retour BOOLEAN,
  Mahngebuehr DECIMAL CHECK(Mahngebuehr <= 100),
  PRIMARY KEY (Faellig, Retour, Entlehnt)
);

CREATE TABLE Ausleihe (
ID integer REFERENCES Benutzer(ID),
Signatur varchar(20) REFERENCES Exemplar(SIgnatur),
Entlehnt date,
Faellig date,
Retour BOOLEAN,
PRIMARY KEY (Signatur, ID, Entlehnt)
);



---  Benutzer
INSERT INTO Benutzer (id, Name, Alter, adresse) VALUES
  (1, 'Jean', 25, 'Carminweg 6, 7000 Chur');
INSERT INTO Benutzer (id, Name, Alter, adresse) VALUES
  (2, 'Karhryn', 22, 'Ringstrasse 2');
INSERT INTO Benutzer (id, Name, Alter, adresse) VALUES
  (3, 'Jonathan', 31, 'Lainach 34');

--- 

Insert into Buch (ISBN, Titel, Verlag, Autor) 
  values (36420520, 'Software','Springer', 'Helfert');


--- Kathrin zieht zu Jean
UPDATE benutzer SET adresse = 'Carminweg 6' where id = 2;
