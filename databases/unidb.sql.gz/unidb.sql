-- Kommerzielle Datenbanksysteme
-- Dr. Albert Weichselbraun

-- Hausuebungsbeispiel http://www.ai.wu-wien.ac.at/~aweichse/dbs/hausuebungen/hue2.pdf
-- Martin Schuch
-- 2006-06-12
-- getestet mit PostgreSQL 8.0



create table person (
SVNr 			char(11) 	primary key,
Name			varchar(50),
Wohnort			varchar(50)
);

create table Lektor (
SVNr			char(11)	primary key references person(SVNr),
Berufsbezeichnung	varchar(20),
Abteilung		varchar(50)
);

create table Student (
SVNr			char(11)	primary key references person(SVNr),
MatrikelNr		int,
Studium		varchar(20)
);


create table Hoersaal (
Bezeichnung		varchar(20)	primary key,
Groesse		int,
Gebaeude		varchar(20)
);

create table Lehrveranstaltung (
LVNr			int		primary key,
Name			varchar(50),
maxTeilnehmer		int,
Ort			varchar(20)	references Hoersaal(Bezeichnung)
);

create table haeltAb (
SVNr			char(11)	references Lektor(SVNr),
LVNr			int		references Lehrveranstaltung(LVNr),
SWS			int,
primary key (SVNr, LVNr)
);

create table besucht (
SVNr			char(11)	references Student(SVNr),
LVNr			int		references Lehrveranstaltung(LVNr),
primary key(SVNr, LVNr)
);

create table setztVoraus (
LVNr			int		references Lehrveranstaltung(LVNr),
Voraussetzung		int		references Lehrveranstaltung(LVNr),
primary key(LVNr, Voraussetzung)
);

insert into Hoersaal values ('Audi-Max', '500', 'UZA1');
insert into Hoersaal values ('H. 0.1', '200', 'UZA1');
insert into Hoersaal values ('SCHR2', '50', 'UZA3');

insert into Lehrveranstaltung values ('0111', 'PFO1', '200', 'H. 0.1');
insert into Lehrveranstaltung values ('0102', 'Marketing1', '400', 'Audi-Max');
insert into Lehrveranstaltung values ('0967', 'Finanzierung1', '50', 'SCHR2');

insert into setztVoraus values ('0111', '0102');
insert into setztVoraus values ('0111', '0967');

insert into Person values ('1234 010170', 'Littich', 'Wien');
insert into Lektor values ('1234 010170', 'Univ.Doz', 'Personal');

insert into Person values ('4321 020272', 'Kurz', 'Graz');
insert into Lektor values ('4321 020272', 'Univ.Prof', 'Marketing');

insert into Person values ('1324 030378', 'Meyer', 'Linz');
insert into Lektor values ('1324 030378', 'Univ.Ass', 'Finanzierung');

insert into haeltAb values ('1234 010170', '0111', '2');
insert into haeltAb values ('4321 020272', '0102', '4');
insert into haeltAb values ('1324 030378', '0967', '2');

insert into Person values ('5678 040480', 'Mustermann', 'Wien');
insert into Student values ('5678 040480', '0123456', 'WI');

insert into Person values ('8765 050585', 'Musterfrau', 'Innsbruck');
insert into Student values ('8765 050585', '6543210', 'BW');

insert into Person values ('5768 060683', 'Musterstudent', 'Salzburg');
insert into Student values ('5768 060683', '1029384', 'HW');

insert into besucht values ('5678 040480', '0102');
insert into besucht values ('5678 040480', '0967');
insert into besucht values ('8765 050585', '0102');
insert into besucht values ('5768 060683', '0967');
